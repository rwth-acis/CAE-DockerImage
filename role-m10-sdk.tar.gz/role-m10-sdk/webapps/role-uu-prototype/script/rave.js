define([
        "order!rave/rave",
        "order!rave/rave_api",
        "order!rave/rave_forms",
        "order!rave/rave_layout",
        "order!rave/rave_opensocial",
        "order!rave/rave_store",
        "order!rave/rave_wookie" ], function() {
	return rave;
});